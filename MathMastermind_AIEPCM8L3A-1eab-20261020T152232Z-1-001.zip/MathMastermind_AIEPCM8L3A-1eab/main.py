
import io
import html
import streamlit as st
from hf import generate_response

SYSTEM_PROMPT = """
You are a Math Mastermind.
For every math problem:
1. Show the solution step by step.
2. Explain the reasoning.
3. Give an alternate method if possible.
4. Verify the answer.
5. Use proper mathematical notation.
6. Explain concepts simply.

Format:
Problem
Steps
Final Answer
Concepts Used
"""

def math_generate(problem, level):
    prompt = f"""
{SYSTEM_PROMPT}

Difficulty Level: {level}
Math Problem: {problem}
"""
    return generate_response(
        prompt,
        temperature=0.1,
        max_tokens=1024
    )

def export_txt(history):
    text = "\n\n".join(
        f"Q{i}: {item['q']}\nA{i}: {item['a']}"
        for i, item in enumerate(history, 1)
    )
    return io.BytesIO(text.encode("utf-8"))

def setup_ui():
    st.set_page_config(
        page_title="Math Mastermind",
        page_icon="🧮",
        layout="centered"
    )

    st.title("🧮 Math Mastermind")
    st.write(
        "Solve math problems with detailed, step-by-step explanations."
    )

    with st.expander("📌 Example Problems"):
        st.markdown("""
        - **Algebra:** Solve 2x² + 5x − 3 = 0
        - **Calculus:** Find the derivative of sin(x²) + ln(x)
        - **Geometry:** Find the area of a triangle
        - **Probability:** Find the probability of getting a sum of 7 with two dice
        """)

    if "history" not in st.session_state:
        st.session_state.history = []

    if "question_number" not in st.session_state:
        st.session_state.question_number = 0

    col1, col2 = st.columns(2)

    with col1:
        if st.button("🗑️ Clear History"):
            st.session_state.history = []
            st.rerun()

    with col2:
        if st.session_state.history:
            st.download_button(
                "📄 Export Solutions",
                data=export_txt(st.session_state.history),
                file_name="Math_Mastermind_Solutions.txt",
                mime="text/plain"
            )

    with st.form("math_form", clear_on_submit=True):
        question = st.text_area(
            "📝 Enter your math problem:",
            height=100,
            placeholder="Example: Solve x² + 5x + 6 = 0"
        )

        level = st.selectbox(
            "Choose difficulty level:",
            ["Basic", "Intermediate", "Advanced"],
            index=1
        )

        submitted = st.form_submit_button(
            "🧠 Solve Problem",
            use_container_width=True
        )

    if submitted:
        if not question.strip():
            st.warning("Please enter a math problem.")
        else:
            with st.spinner("Solving your problem..."):
                answer = math_generate(question.strip(), level)

            st.session_state.history.insert(
                0,
                {
                    "q": question.strip(),
                    "a": answer,
                    "lvl": level
                }
            )

            st.session_state.question_number += 1

    if st.session_state.history:
        st.markdown("## 🧾 Solution History")

        for i, item in enumerate(st.session_state.history, 1):
            with st.container(border=True):
                st.markdown(f"**Question {i}:** {item['q']}")
                st.caption(f"Level: {item['lvl']}")
                st.markdown("**Solution:**")

                # Display answers safely as Markdown.
                st.markdown(item["a"])


if __name__ == "__main__":
    setup_ui()
