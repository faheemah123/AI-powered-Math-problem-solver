
# hf.py
import config
from huggingface_hub import InferenceClient

MODELS = getattr(
    config,
    "HF_MODELS",
    ["Qwen/Qwen2.5-7B-Instruct"]
)

def generate_response(
    prompt: str,
    temperature: float = 0.3,
    max_tokens: int = 512
) -> str:

    key = getattr(config, "HF_API_KEY", None)

    if not key or not key.startswith("hf_"):
        return (
            "Error: HF_API_KEY is missing or invalid in config.py. "
            "Create a token at https://huggingface.co/settings/tokens"
        )

    last_err = None

    try:
        client = InferenceClient(token=key, provider="auto")

        for model in MODELS:
            try:
                result = client.chat_completion(
                    model=model,
                    messages=[
                        {"role": "user", "content": prompt}
                    ],
                    temperature=temperature,
                    max_tokens=max_tokens,
                )

                answer = result.choices[0].message.content
                return answer or "The model returned an empty response."

            except Exception as e:
                last_err = e

                # A bad token cannot be fixed by trying another model.
                if "401" in str(e) or "Unauthorized" in str(e):
                    return (
                        "Hugging Face authentication failed (401). "
                        "Check HF_API_KEY in config.py and create a "
                        "valid token with Inference Providers permission."
                    )

        return (
            f"Hugging Face models failed: {MODELS}\n"
            f"Error: {type(last_err).__name__}: {last_err}"
        )

    except Exception as e:
        return f"Hugging Face error: {type(e).__name__}: {e}"
